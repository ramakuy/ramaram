const help = (prefix) => { 
	return `🔹𝗣𝗨𝗗𝗜𝗗𝗜𝗫𝗕𝗢𝗧🔹

● *Status* : *Online*
● *Version* : *4.0*
● *User* : *@${num.split('@')[0]}*
● *Groubs* : *24*
● *Pengguna* : *37*
● *Fitur* : *121*
● *Web Api* : *xptnbotapi.herokuapp.com*
● *Special Thanks To* :
●———  *XP-TN*  ———
●———— *Alfa* ————

╔▣━━━━━❨ 𝗦𝗧𝗜𝗖𝗞𝗘𝗥 ❩━━━━━▣┓
║┃
║┣➤ *${prefix}sticker*
║┣➤ *${prefix}tsticker*
║┃
┣▣━━━━━❨    𝗠𝗢𝗥𝗘    ❩━━━━━▣┓
║┃
║┣➤ *${prefix}donasi*
║┣➤ *${prefix}info*
║┃
┣▣━━━━━❨   𝗠𝗔𝗞𝗘𝗥   ❩━━━━━▣┓
║┃
║┣➤ *${prefix}nulis <teks>*
║┣➤ *${prefix}text3d <teks>*
║┣➤ *${prefix}ninjalogo <teks>*
║┣➤ *${prefix}wolflogo <teks>*
║┣➤ *${prefix}lionlogo <teks>*
║┣➤ *${prefix}textscreen <teks>*
║┣➤ *${prefix}tahta <teks>*
║┣➤ *${prefix}rtext <teks>*
║┣➤ *${prefix}thunder <teks>*
║┣➤ *${prefix}glitch <teks | teks>*
║┣➤ *${prefix}party <teks>*
║┣➤ *${prefix}lovemake <teks>*
║┣➤ *${prefix}galaxtext <teks>*
║┣➤ *${prefix}pronlogo <teks>*
║┣➤ *${prefix}stiltext <teks>*
║┣➤ *${prefix}quotemaker <teks>*
║┃
┣▣━━━━━❨ 𝗙𝗨𝗡 𝗖𝗠𝗗 ❩━━━━━▣┓
║┃
║┣➤ *${prefix}quotes*
║┣➤ *${prefix}lirik*
║┣➤ *${prefix}bucin*
║┣➤ *${prefix}tebakgambar*
║┣➤ *${prefix}caklontong*
║┣➤ *${prefix}family100*
║┣➤ *${prefix}game*
║┣➤ *${prefix}primbonjodoh <nama> | <nama>*
║┣➤ *${prefix}artinama <nama>*
║┣➤ *${prefix}ramalhp <nomor>*
║┣➤ *${prefix}ytsearch*
║┣➤ *${prefix}ssweb*
║┣➤ *${prefix}shorturl*
║┣➤ *${prefix}map*
║┣➤ *${prefix}ceckjodoh*
║┣➤ *${prefix}walpaperhd*
║┣➤ *${prefix}toimg*
║┣➤ *${prefix}report*
║┣➤ *${prefix}meme*
║┣➤ *${prefix}memeindo*
║┣➤ *${prefix}simi*
║┣➤ *${prefix}apakah*
║┣➤ *${prefix}bisakah*
║┣➤ *${prefix}kapankah*
║┣➤ *${prefix}watak*
║┣➤ *${prefix}mlherolist*
║┣➤ *${prefix}fototiktok*
║┣➤ *${prefix}playstore*
║┣➤ *${prefix}kbbi*
║┣➤ *${prefix}say*
║┣➤ *${prefix}wiki*
║┣➤ *${prefix}truth*
║┣➤ *${prefix}dare*
║┣➤ *${prefix}rate*
║┣➤ *${prefix}inu*
║┣➤ *${prefix}fitnah*
║┣➤ *${prefix}hilih*
║┣➤ *${prefix}speed*
║┣➤ *${prefix}brainly*
║┣➤ *${prefix}image*
║┣➤ *${prefix}pinterest*
║┣➤ *${prefix}indohot*
║┣➤ *${prefix}randomcat*
║┣➤ *${prefix}joox*
║┣➤ *${prefix}tts <teks>*
║┣➤ *${prefix}url2img*
║┃
┣▣━━━━━❨    𝗡𝗦𝗙𝗪    ❩━━━━━▣┓
║┃
║┣➤ *${prefix}randomhentai*
║┣➤ *${prefix}nsfwtrap*
║┣➤ *${prefix}nsfwloli*
║┣➤ *${prefix}nsfwneko*
║┣➤ *${prefix}nsfwblowjob*
║┃
┣▣━━━━━❨ 𝗔𝗡𝗜𝗠𝗔𝗟𝗦 ❩━━━━━▣┓
║┃
║┣➤ *${prefix}elang*
║┣➤ *${prefix}babi*
║┣➤ *${prefix}unta*
║┣➤ *${prefix}anjing*
║┣➤ *${prefix}pokemon*
║┃
┣▣━━━❨  𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗  ❩━━━━▣┓
║┃
║┣➤ *${prefix}ytsearch* [search yt]
║┣➤ *${prefix}ytmp3* [link]
║┣➤ *${prefix}ytmp4* [link]
║┣➤ *${prefix}tiktok* [link]
║┃
┣▣━━━━━❨  𝗚𝗥𝗢𝗨𝗕  ❩━━━━━▣┓
║┃
║┣➤ *${prefix}add* [62xxx]
║┣➤ *${prefix}kick* [tag]
║┣➤ *${prefix}setpp*
║┣➤ *${prefix}setname*
║┣➤ *${prefix}setdesc*
║┣➤ *${prefix}demote* [tag]
║┣➤ *${prefix}promote* [tag]
║┣➤ *${prefix}tagall*
║┣➤ *${prefix}group* [buka/tutup]
║┣➤ *${prefix}welcome* [1/0]
║┣➤ *${prefix}nsfw* [1/0]
║┣➤ *${prefix}simih* [1/0]
║┣➤ *${prefix}listadmin*
║┣➤ *${prefix}groupinfo
║┣➤ *${prefix}hidetag*
║┣➤ *${prefix}tagme*
║┣➤ *${prefix}delete*
║┃
┣▣━━━━━❨    𝗜𝗡𝗙𝗢    ❩━━━━━▣┓
║┃
║┣➤ *${prefix}infonomor*
║┣➤ *${prefix}infomotor*
║┣➤ *${prefix}infomobil*
║┣➤ *${prefix}blocklist*
║┣➤ *${prefix}infogempa*
║┣➤ *${prefix}infogithub*
║┣➤ *${prefix}infocuaca*
║┣➤ *${prefix}resepmasakan*
║┣➤ *${prefix}creator*
║┃
┣▣━━━━❨   𝗢𝗪𝗡𝗘𝗥   ❩━━━━━▣┓
║┃
║┣➤ *${prefix}bc* 
║┣➤ *${prefix}leave*
║┣➤ *${prefix}clearall*
║┣➤ *${prefix}setprefix*
║┣➤ *${prefix}clone* [tag]
║┣➤ *${prefix}block*
║┣➤ *${prefix}unblock*
║┣➤ *${prefix}getses*
║┃
┣▣━━━━━❨    𝗪𝗜𝗕𝗨    ❩━━━━━▣┓
║┃
║┣➤ *${prefix}nekonime*
║┣➤ *${prefix}randomanime*
║┣➤ *${prefix}wait*
║┣➤ *${prefix}anime*
║┣➤ *${prefix}loli*
║┣➤ *${prefix}waifu*
║┃
┣▣━━━━━❨   𝗦𝗧𝗔𝗟𝗞   ❩━━━━━▣┓
║┃
║┣➤ *${prefix}tiktokstalk*
║┣➤ *${prefix}igstalk*
┣━━━━━━━━━━━━━━━━━━━━
║🔹𝗧𝗛𝗜𝗦 𝗕𝗢𝗧 𝗕𝗬 𝗔𝗥𝗠𝗔𝗡𝗧𝗢𝗗🔹
╚━━━━━━━━━━━━━━━━━━━━`
}
exports.help = help